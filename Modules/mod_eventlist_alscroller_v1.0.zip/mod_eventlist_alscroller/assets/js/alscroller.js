/* ALScroller (C) 2009 Adrian Levano. All rights reserved.

Version 1.0.1 (Mootools 1.11)
ALScroller is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/
var ALScroller = new Class( {
	options: {
            duration : 500,
            delay : 5000,
            container: null,
            wrapper:'.elmodscroll_wrapper',
            inner:'.elmodscroll_inner',
            items: '.elmodscroll_content',
            prevBtn :'.elmodscroll_prev',
            nextBtn :'.elmodscroll_next',
            playBtn :'.elmodscroll_play',
            pauseBtn :'.elmodscroll_pause',
            pageBtn :'.elmodscroll_page',
            autoanim: true,
            direction : 1,
            transition: Fx.Transitions.Bounce.easeOut,
            wheelstop: false,
            pauseable: false,
            restart_beginning:	false
	},
	current:	0,
	container:	null,
	wrapper:	null,
	inner:		null,
	items:		null,
	prevBtn:	null,
	nextBtn:	null,
	playBtn:	null,
	pauseBtn:	null,
	pageBtn:	null,
	scroll:		null,
	paused:		false,
	timer:		null,

	initialize : function(options) {
		this.setOptions(options);
		this.container = $(this.options.container);
		this.wrapper = this.container.getElement(this.options.wrapper);
		this.inner = this.container.getElement(this.options.inner);
		this.items = this.container.getElements(this.options.items);
		this.prevBtn = this.container.getElement(this.options.prevBtn);
		this.nextBtn = this.container.getElement(this.options.nextBtn);
		this.playBtn = this.container.getElement(this.options.playBtn);
		this.pauseBtn = this.container.getElement(this.options.pauseBtn);
		this.pageBtn = this.container.getElements(this.options.pageBtn);
		this.scroll = new Fx.Scroll(this.wrapper, {wait: false,duration: this.options.duration,wheelStops: this.options.wheelstop,transition:this.options.transition});	
	
		if($defined(this.prevBtn)) {
			this.prevBtn.addEvent('click', function(e) {
				e = new Event(e).stop();
				if (this.options.direction == -1) this.next();
				else this.prev();
			}.bind(this));
		}
		
		if($defined(this.nextBtn)) {
			this.nextBtn.addEvent('click', function(e) {
				e = new Event(e).stop();
				if (this.options.direction == -1) this.prev();
				else this.next();
			}.bind(this)); 
		}

		if($defined(this.playBtn)) {
			this.playBtn.addEvent('click', function(e) {
				e = new Event(e).stop();
				this.play();
			}.bind(this)); 
		}
		
		if($defined(this.pauseBtn)) {
			this.pauseBtn.addEvent('click', function(e) {
				e = new Event(e).stop();
				this.pause();
			}.bind(this)); 
		}
		
		if($defined(this.pageBtn)) {
			this.pageBtn.each(function(item,index) { 
				item.addEvent('click', function(e) {
					e = new Event(e).stop();
					if (this.options.direction == -1) this.page((this.items.length-1)-index);
					else this.page(index);
				}.bind(this));
			}.bind(this)); 
		}		

		if(this.options.autoanim && this.options.pauseable ) {
			this.wrapper.addEvent('mouseover', this.pause.bind(this));
			this.wrapper.addEvent('mouseout', this.play.bind(this));
		}
		
		if (this.options.scrollaxis=='x') {
			this.offset = this.wrapper.getSize().size.y;
		}else {
			this.offset = this.wrapper.getSize().size.x;
		}
		
		if (this.options.direction == -1) this.current = this.items.length-1;
		else this.current = 0;

		this.scrollToElement();

	},
	scrollToElement : function() {
		var current_page=0;
		if (this.options.direction == -1){ 
			current_page = (this.items.length-1) - this.current;
		} else { 
			current_page = this.current;
		}
		this.scroll.toElement(this.items[this.current]);
		if($defined(this.pageBtn)){
			this.pageBtn.removeClass('elmodscroll_current');
            if($defined(this.pageBtn[current_page])){
                this.pageBtn[current_page].addClass('elmodscroll_current');
            }
		}
		if(this.options.autoanim) this.timer = this.repeat.delay(this.options.duration + this.options.delay, this);
	},
	repeat : function() {
		if (!this.paused) {		
			if (this.options.direction == 1) this.next();
			else this.prev();
		}		
	},
	play : function() {
		this.paused = false;
		this.timer = this.repeat.delay(this.options.delay, this);
	},
	pause : function() {
		this.paused = true;
		$clear(this.repeat);
		$clear(this.timer);
	},
	next : function() {		
		$clear(this.repeat);
		$clear(this.timer);
		if (this.current == this.items.length - 1) this.current = 0;
		else this.current++;
		this.scrollToElement();
	},
	prev : function() {
		$clear(this.repeat);
		$clear(this.timer);
		if (this.current == 0) this.current = this.items.length - 1;
		else this.current--;
		this.scrollToElement();
	},
	page : function(index) {
		$clear(this.repeat);
		$clear(this.timer);
		this.current = index;
		this.scrollToElement();
	}	
});

ALScroller.implement(new Options);