<?php
/**
 * @version 1.0 $Id: helper.php 258 2009-11-20 21:23:05Z jrgadrian $
 * @package Joomla
 * @subpackage AL EventList Scroller Module
 * @copyright (C) 2009 Adrian Levano. All rights reserved.
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * AL EventList Scroller Module is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 2
 * as published by the Free Software Foundation.

 * AL EventList Scroller Module is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * AL EventList Scroller Module is based on EventList Wide Module by Christoph Lukes
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * AL EventList Scroller Module helper
 *
 * @package Joomla
 * @subpackage AL EventList Scroller Module
 * @since 1.0
 */
class modEventListALScrollerHelper {
	/**
	 * Method to get the events
	 *
	 * @access public
	 * @return array
	 */
	function getList(&$params) {
			
			
		global $mainframe;

		$db			= &JFactory::getDBO();
		$user		= &JFactory::getUser();
		$user_gid	= (int) $user->get('aid');


		//clean parameter data
		$event_type     = $params->get( 'type', '1' );
		$count          = (int)$params->get( 'count', '2' );
		$catid          = trim( $params->get('catid') );
		$venid          = trim( $params->get('venid') );
		$stateloc       = JString::strtolower(trim( $params->get('stateloc') ) );
		$cityloc        = JString::strtolower(trim( $params->get('cityloc') ) );
		$countryloc     = JString::strtolower(trim( $params->get('countryloc') ) );
		$eveid          = trim( $params->get('eveid') );
		$sort_value     = $params->get( 'events_sort_value', 'dates' );
		$sort_order     = $params->get( 'events_sort_order', 'DESC' );//get data for thumbs
		$showimage		= $params->get('showimage', 0);
		$imagewidth 	= $params->get('imagewidth', 50) ;
		$imageheight 	= $params->get('imageheight', 50);
		$imagestretch 	= $params->get('imagestretch', 0);
		$imagequality 	= $params->get('imagequality', 95);
		$eventswithouthimage = $params->get('eventswithouthimage', 0);
		$cachetime		= $params->get('cachetime', 30);
		$showauthor     = $params->get('showauthor',0);
		$showcbavatar   = $params->get('showcbavatar',0);
		$linkcbprofile  = $params->get('linkcbprofile',0);
		$elversion		= $params->get('elversion',0);

		
		

		//all published events
		if ($event_type == 0) {
			$where = ' WHERE a.published = 1';
		}

		//all upcoming events
		if ($event_type == 1) {
			$where = ' WHERE a.dates >= CURDATE()';
			$where .= ' AND a.published = 1';
		}

		//archived events only
		if ($event_type == 2) {
			$where = ' WHERE a.published = -1';
		}

		//currently running events only
		if ($event_type == 3) {
			$where = ' WHERE a.published = 1';
			$where .= ' AND ( a.dates = CURDATE()';
			$where .= ' OR ( a.enddates >= CURDATE() AND a.dates <= CURDATE() ))';
		}
		
		//Week Events starting Monday
		if ($event_type == 4) {
			$where = ' WHERE (a.dates >= DATE_ADD(CURDATE(),INTERVAL(0-WEEKDAY(CURDATE())) DAY)';
			$where .= '  AND a.dates <= DATE_ADD(CURDATE(),INTERVAL(6-WEEKDAY(CURDATE())) DAY))';
			//$where .= '   OR(a.enddates >= DATE_ADD(CURDATE(),INTERVAL(0-WEEKDAY(CURDATE())) DAY)';
			//$where .= '  AND a.enddates <= DATE_ADD(CURDATE(),INTERVAL(6-WEEKDAY(CURDATE())) DAY)))';
			$where .= '  AND a.published = 1';
		}
		
		//Week Events starting Sunday
		if ($event_type == 5) {
			$where = ' WHERE (a.dates >= DATE_ADD(CURDATE(),INTERVAL(1-DAYOFWEEK(CURDATE())) DAY)';
			$where .= '  AND a.dates <= DATE_ADD(CURDATE(),INTERVAL(7-DAYOFWEEK(CURDATE())) DAY))';
			//$where .= '  OR (a.enddates >= DATE_ADD(CURDATE(),INTERVAL(1-DAYOFWEEK(CURDATE())) DAY)';
			//$where .= '  AND a.enddates <= DATE_ADD(CURDATE(),INTERVAL(7-DAYOFWEEK(CURDATE())) DAY)))';
			$where .= '  AND a.published = 1';
		}
	
		//Week Events starting Today
		if ($event_type == 6) {
			$where = ' WHERE a.dates >= CURDATE()';
			$where .= '  AND a.dates <= DATE_ADD(CURDATE(),INTERVAL(6) DAY)';
			$where .= '  AND a.published = 1';
		}
		

		//Build category selection query statement
		if ($catid) {
			$ids = explode( ',', $catid );
			JArrayHelper::toInteger( $ids );
			$categories = ' AND (c.id=' . implode( ' OR c.id=', $ids ) . ')';
		}

		//Build venue selection query statement
		if ($venid) {
			$ids = explode( ',', $venid );
			JArrayHelper::toInteger( $ids );
			$venues = ' AND (l.id=' . implode( ' OR l.id=', $ids ) . ')';
		}

		//Build event selection query statement
		if ($eveid) {
			$ids = explode( ',', $eveid );
			JArrayHelper::toInteger( $ids );
			$events = ' AND (a.id=' . implode( ' OR a.id=', $ids ) . ')';
		}

		//Build state selection query statement
		if ($stateloc) {
			$rawstate = explode( ',', $stateloc );

			foreach ($rawstate as $val) {
				if ($val) {
					$state[] = '"'.trim($db->getEscaped($val)).'"';
				}
			}

			JArrayHelper::toString( $state );
			$states = ' AND (LOWER(l.state)='.implode(' OR LOWER(l.state)=',$state).')';
		}

		//Build city selection query statement
		if ($cityloc) {
			$rawcity = explode( ',', $cityloc );

			foreach ($rawcity as $val) {
				if ($val) {
					$city[] = '"'.trim($db->getEscaped($val)).'"';
				}
			}

			JArrayHelper::toString( $city );
			$cities = ' AND (LOWER(l.city)='.implode(' OR LOWER(l.city)=',$city).')';
		}
		
		//Build country selection query statement
		if ($countryloc) {
			$rawcountry = explode( ',', $countryloc );

			foreach ($rawcountry as $val) {
				if ($val) {
					$country[] = '"'.trim($db->getEscaped($val)).'"';
				}
			}

			JArrayHelper::toString( $country );
			$countries = ' AND (LOWER(l.country)='.implode(' OR LOWER(l.country)=',$country).')';
		}
		// Ordering string
		$order = '';
		// When sort value is random
		if($sort_value == 'random') {
			$order = ' RAND()';
		}
		else // when sort value is different than random
		{
			if($sort_value != 'dates') $order = $sort_value.' '.$sort_order.' , dates '.$sort_order.', times '. $sort_order;
			else $order = 'dates '.$sort_order.', times '. $sort_order;
		}

		//perform select query
		$query = 'SELECT DISTINCT a.id, a.title, a.dates, a.enddates, a.datdescription, a.times, a.endtimes, a.datimage, l.venue, l.street, l.city, l.state, l.country, l.locimage, c.catname,'
		.' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(\':\', a.id, a.alias) ELSE a.id END as slug,'
		.' CASE WHEN CHAR_LENGTH(l.alias) THEN CONCAT_WS(\':\', l.id, l.alias) ELSE l.id END as venueslug,'
		.' CASE WHEN CHAR_LENGTH(c.alias) THEN CONCAT_WS(\':\', c.id, c.alias) ELSE c.id END as categoryslug'
		.($showauthor?' ,u.id as uid, u.'.(($params->get('username') == 1) ? 'username':'name') .' AS author':'')//author
		.($showcbavatar?' , cb.avatar':'') //avatar
		.' FROM #__eventlist_events AS a'
		.($elversion?(
         ' INNER JOIN #__eventlist_cats_event_relations AS rel ON rel.itemid = a.id'
        .' LEFT JOIN #__eventlist_categories AS c ON c.id = rel.catid')
		:' LEFT JOIN #__eventlist_categories AS c ON c.id = a.catsid')
		.' LEFT JOIN #__eventlist_venues AS l ON l.id = a.locid'
		.($showauthor?' LEFT JOIN #__users AS u ON u.id = a.created_by':'') //author
		.($showcbavatar?' LEFT JOIN #__comprofiler as cb ON cb.user_id = u.id':'')  // avatar
		. $where
		.' AND c.access <= '.$user_gid
		.($showimage && $eventswithouthimage==2? ' AND a.datimage <> ""':'')//supress events withouth image from results
		.($catid ? $categories : '')
		.($venid ? $venues : '')
		.($stateloc ? $states : '')
		.($cityloc ? $cities : '')
		.($countryloc ? $countries : '')
		.($eveid ? $events : '')
		.($elversion? ' GROUP BY a.id':'')
		.' ORDER BY '.$order
		.($count?' LIMIT '.$count:'')
		;
		$db->setQuery($query);
		$rows = $db->loadObjectList();

		//get gd version
		$gd_version = ELImage::gdVersion();

		//Loop through the result rows and prepare data
		$i = 0;
		$lists = array();
		foreach ( $rows as $row ) {
			
			//cut title
			$length = strlen(htmlspecialchars( $row->title ));
			if ($length > $params->get('cuttitle', '25')) {
				$row->title = substr($row->title, 0, $params->get('cuttitle', '18'));
				$row->title = $row->title.'...';
			}

			$lists[$i]->title	    = htmlspecialchars( $row->title, ENT_COMPAT, 'UTF-8' );
			$lists[$i]->catname	    = htmlspecialchars( $row->catname, ENT_COMPAT, 'UTF-8' );
			$lists[$i]->venue	    = htmlspecialchars( $row->venue, ENT_COMPAT, 'UTF-8' );
			$lists[$i]->street	    = htmlspecialchars( $row->street, ENT_COMPAT, 'UTF-8' );
			$lists[$i]->city	    = htmlspecialchars( $row->city, ENT_COMPAT, 'UTF-8' );
			$lists[$i]->state	    = htmlspecialchars( $row->state, ENT_COMPAT, 'UTF-8' );
			$lists[$i]->country     = htmlspecialchars( $row->country, ENT_COMPAT, 'UTF-8' );
			if ($row->country) {
				$lists[$i]->countryimg  = modEventListALScrollerHelper::_getFlag( $row->country );
			}
			$lists[$i]->eventlink   = JRoute::_( EventListHelperRoute::getRoute($row->slug),false,-1 );
			$lists[$i]->venuelink   = $params->get('linkvenue', 1) ? JRoute::_( EventListHelperRoute::getRoute($row->venueslug, 'venueevents') ) : '';
			$lists[$i]->categorylink= $params->get('linkcategory', 1) ? JRoute::_( EventListHelperRoute::getRoute($row->categoryslug, 'categoryevents') ) : '';
			$lists[$i]->date	    = modEventListALScrollerHelper::_format_date($row->dates, $row->times, $params->get('formatdate', '%d.%m.%Y'));//modEventListALScrollerHelper::_format_date($row, $params);
			$lists[$i]->enddate     = $row->enddates ? modEventListALScrollerHelper::_format_date($row->enddates, $row->endtimes, $params->get('formatdate', '%d.%m.%Y')) : null;
			$lists[$i]->time	    = $row->times ? modEventListALScrollerHelper::_format_time($row->dates, $row->times, $params) : '' ;
			$lists[$i]->endtime	    = $row->endtimes ? modEventListALScrollerHelper::_format_time($row->enddates, $row->endtimes, $params) : '' ;
				
			if($showimage && $gd_version == 2) {
				$origfilepath = null;
				
				if($row->datimage) {
					$origfilepath = 'images/eventlist/events/'.$row->datimage;
				} else {
					if($eventswithouthimage==0){
						$origfilepath = 'modules/mod_eventlist_alscroller/assets/images/noimage.png';
					}
				}
				if($origfilepath){
					//get imagesize of the original
					$iminfo = @getimagesize(JPATH_SITE.'/'.$origfilepath);
	
					if($iminfo) {					
						if(!$imagestretch) {
							$iRatioW = $imagewidth / $iminfo[0];
							$iRatioH = $imageheight / $iminfo[1];
							if ($iRatioW < $iRatioH) {
								$width	= round($iminfo[0] * $iRatioW);
								$height = round($iminfo[1] * $iRatioW);
							} else {
								$width	= round($iminfo[0] * $iRatioH);
								$height = round($iminfo[1] * $iRatioH);
							}
						} else{
							$width	= $imagewidth;
							$height = $imageheight;
						}
						//Don't resize images which are smaller than thumbs
						/*if ($iminfo[0] < $imagewidth && $iminfo[1] < $imageheight) {
							$width	= $iminfo[0];
							$height = $iminfo[1];
						}*/
		
						if($row->datimage) {
							$thumbfilepath = 'modules/mod_eventlist_alscroller/cache/'.$width.'x'.$height.'_'.$row->datimage;
						} else {
							$thumbfilepath = 'modules/mod_eventlist_alscroller/cache/'.$width.'x'.$height.'_noimage.png';
						}
						if (!file_exists(JPATH_SITE.'/'.$thumbfilepath)) {
							$filepath 	= JPATH_SITE.'/'.$origfilepath;
							$save 		= JPATH_SITE.'/'.$thumbfilepath;
							modEventListALScrollerHelper::_thumb($filepath,$save,$width,$height,$imagequality);
						}
					}else{
						$thumbfilepath = $origfilepath;
						$width = $imagewidth;
						$height = $imageheight;
					}
					$lists[$i]->eventimage		= JURI::base(true).'/'.$thumbfilepath;
					$lists[$i]->eventimagew		= $width;
					$lists[$i]->eventimageh		= $height;
					$lists[$i]->eventimageorig	= JURI::base(true).'/'.$origfilepath;
				} else{
					$lists[$i]->eventimage		= null;
					$lists[$i]->eventimageorig	= null;
				}
			}

			if($showauthor) $lists[$i]->author = htmlspecialchars( $row->author, ENT_COMPAT, 'UTF-8' );
			if($linkcbprofile) $lists[$i]->authorcbprofile = JRoute::_('index.php?option=com_comprofiler&task=userProfile&user='.$row->uid);

			// Trim description
			$description = trim($row->datdescription);
			// Remove description plugins
			$description = preg_replace("/\{.+?\}/", "", $description);
			// Strip Description HTML Tags
			$description = modEventListALScrollerHelper::_strip_html_tags($description);
			// Strip Description BBCode Tags
			$description = modEventListALScrollerHelper::_strip_BBCode($description);
			// Cut Description
			$length = $params->get('cutdescription', '50');
			$etc = '...';
			if (strlen($description) > $length) {
				$length -= strlen($etc);
				//$description = preg_replace('/\s+?(\S+)?$/', '', substr($description, 0, $length+1));
				$lists[$i]->eventdescription = substr($description, 0, $length).$etc;
			} else {
				$lists[$i]->eventdescription = $description;
			}

			$i++;
		}

		return $lists;
	}

	/**
	 * Method to remove HTML tags, including invisible text such as
	 * style and script code, and embedded objects. Add line breaks
	 * around block-level tags to prevent word joining after tag removal.
	 *
	 * @access public
	 * @param string $text
	 * @return string
	 */
	function _strip_html_tags( $text )
	{
		$text = preg_replace(
		array(
		// Remove invisible content
	            '@<head[^>]*?>.*?</head>@siu',
	            '@<style[^>]*?>.*?</style>@siu',
	            '@<script[^>]*?.*?</script>@siu',
	            '@<object[^>]*?.*?</object>@siu',
	            '@<embed[^>]*?.*?</embed>@siu',
	            '@<applet[^>]*?.*?</applet>@siu',
	            '@<noframes[^>]*?.*?</noframes>@siu',
	            '@<noscript[^>]*?.*?</noscript>@siu',
	            '@<noembed[^>]*?.*?</noembed>@siu',
		// Add line breaks before and after blocks
	            '@</?((address)|(blockquote)|(center)|(del))@iu',
	            '@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
	            '@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
	            '@</?((table)|(th)|(td)|(caption))@iu',
	            '@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
	            '@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
	            '@</?((frameset)|(frame)|(iframe))@iu',
		),
		array(
	            ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	            "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
	            "\n\$0", "\n\$0",
		),
		$text );
		return strip_tags( $text );
	}

	/**
	 * Method to remove BBcode tags.
	 *
	 * @access public
	 * @param string $text
	 * @return string
	 */
	function _strip_BBCode($text_to_search) {
		$pattern = '|[[\/\!]*?[^\[\]]*?]|si';
		$replace = '';
		return preg_replace($pattern, $replace, $text_to_search);
	}

	/**
	 * Method to format date information
	 * @access public
	 * @param string $date
	 * @param string $time
	 * @param string $format
	 * @return string
	 */
	function _format_date($date, $time, $format) {
		//format date
		$date = strftime($format, strtotime( $date.' '.$time ));
		return $date;
	}

	/**
	 * Method to format time information
	 *
	 * @access public
	 * @param string $date
	 * @param string $time
	 * @param array $params
	 * @return string
	 */
	function _format_time($date, $time, &$params) {
		$time = strftime( $params->get('formattime', '%H:%M'), strtotime( $date.' '.$time ));
		return $time;
	}

	/**
	 * Creates the country flag
	 *
	 * @param string $country
	 * @return string
	 * @since 0.9
	 */
	function _getFlag($country) {
		$country = JString::strtolower($country);

		jimport('joomla.filesystem.file');
		if (JFile::exists(JPATH_SITE.DS.'components'.DS.'com_eventlist'.DS.'assets'.DS.'images'.DS.'flags'.DS.$country.'.gif')) {
			$countryimg = '<img src="'.JURI::base(true).'/components/com_eventlist/assets/images/flags/'.$country.'.gif" alt="'.JText::_( 'COUNTRY' ).': '.$country.'" width="16" height="11" />';

			return $countryimg;
		}

		return null;
	}

	/**
	 * Method to create a thumbnail image
	 *
	 * @param string $file The path to the file
	 * @param string $save The targetpath
	 * @param string $width The with of the image
	 * @param string $height The height of the image
	 * @param string $quality The quality of the image
	 * @return true when success
	 */
	function _thumb($file, $save, $width, $height, $quality) {
		//GD-Lib > 2.0 only!
		@unlink($save);

		//get sizes else stop
		if (!$iminfo = @getimagesize($file)) {
			return false;
		}

		if($iminfo[2] == 1) {
			/*
			 * Image is typ gif
			 */
			$imgA = imagecreatefromgif($file);
			$imgB = imagecreate($width,$height);

			//keep gif transparent color if possible
			if(function_exists('imagecolorsforindex') && function_exists('imagecolortransparent')) {
				$transcolorindex = imagecolortransparent($imgA);
				//transparent color exists
				if($transcolorindex >= 0 ) {
					$transcolor = imagecolorsforindex($imgA, $transcolorindex);
					$transcolorindex = imagecolorallocate($imgB, $transcolor['red'], $transcolor['green'], $transcolor['blue']);
					imagefill($imgB, 0, 0, $transcolorindex);
					imagecolortransparent($imgB, $transcolorindex);
					//fill white
				} else {
					$whitecolorindex = @imagecolorallocate($imgB, 255, 255, 255);
					imagefill($imgB, 0, 0, $whitecolorindex);
				}
				//fill white
			} else {
				$whitecolorindex = imagecolorallocate($imgB, 255, 255, 255);
				imagefill($imgB, 0, 0, $whitecolorindex);
			}
			imagecopyresampled($imgB, $imgA, 0, 0, 0, 0, $width, $height, $iminfo[0], $iminfo[1]);
			imagegif($imgB, $save);

		} elseif($iminfo[2] == 2) {
			/*
			 * Image is typ jpg
			 */
			$imgA = imagecreatefromjpeg($file);
			$imgB = imagecreatetruecolor($width,$height);
			imagecopyresampled($imgB, $imgA, 0, 0, 0, 0, $width, $height, $iminfo[0], $iminfo[1]);
			imagejpeg($imgB, $save, $quality);

		} elseif($iminfo[2] == 3) {
			/*
			 * Image is typ png
			 */
			$imgA = imagecreatefrompng($file);
			$imgB = imagecreatetruecolor($width, $height);
			imagealphablending($imgB, false);
			imagecopyresampled($imgB, $imgA, 0, 0, 0, 0, $width, $height, $iminfo[0], $iminfo[1]);
			imagesavealpha($imgB, true);
			imagepng($imgB, $save);
		} else {
			return false;
		}
		return true;
	}

}

