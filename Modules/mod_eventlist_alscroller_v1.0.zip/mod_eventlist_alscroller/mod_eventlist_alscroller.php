<?php
/**
 * @version 1.0 $Id: mod_eventlist_alscroller.php 258 2009-11-20 21:23:05Z jrgadrian $
 * @package Joomla
 * @subpackage AL EventList Scroller Module
 * @copyright (C) 2009 Adrian Levano. All rights reserved.
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * AL EventList Scroller Module is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 2
 * as published by the Free Software Foundation.

 * AL EventList Scroller Module is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * AL EventList Scroller Module is based on EventList Wide Module by Christoph Lukes
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// get helper
require_once (dirname(__FILE__).DS.'helper.php');


//require needed component classes
require_once(JPATH_SITE.DS.'components'.DS.'com_eventlist'.DS.'helpers'.DS.'helper.php');
require_once(JPATH_SITE.DS.'components'.DS.'com_eventlist'.DS.'helpers'.DS.'route.php');
require_once (JPATH_SITE.DS.'components'.DS.'com_eventlist'.DS.'classes'.DS.'image.class.php');

// Get events list
$list = modEventListALScrollerHelper::getList($params);

// check if any results returned
$totalitems = count($list);
if (!$totalitems) {
	//echo JText::_('NO_ITEMS_FOUND');
    return;
}

$moduleclass_sfx = $params->get( 'moduleclass_sfx' );
$module_id	= $params->get('module_unique_id', 'alscroller1');
$autoanim	= $params->get('autoanim', 0)?'true':'false';
$duration	= $params->get('duration', 500);
$delay		= $params->get('delay', 5000);
$direction	= $params->get('direction', 1);
$pauseable	= $params->get('pauseable', 0)?'true':'false';
$wheelstop	= $params->get('wheelstop', 0)?'true':'false';
$transition	= 'Fx.Transitions.'.$params->get('trans_effect', 'Sine').'.'.$params->get('trans_style', 'easeOut');

$document = & JFactory::getDocument();

if($params->get('use_css',1)){
    $document->addStyleSheet(JURI::root(true).'/modules/mod_eventlist_alscroller/assets/css/alscroller.css');
}

if($params->get('use_mootools',1)){
	
    JHTML::_('behavior.mootools');
	
    $document->addScript ( JURI::root(true) . '/modules/mod_eventlist_alscroller/assets/js/domready.js' );
    $document->addScript ( JURI::root(true) . '/modules/mod_eventlist_alscroller/assets/js/alscroller.js' );
	
    $js = "
    DomReady.ready(function() {
	var $module_id = new ALScroller({container:'$module_id',autoanim:$autoanim,duration:$duration,delay:$delay,direction:$direction,pauseable:$pauseable,wheelstop:$wheelstop,transition:$transition});
    });
    ";
    $document->addScriptDeclaration ( $js );
}

require(JModuleHelper::getLayoutPath('mod_eventlist_alscroller'));
