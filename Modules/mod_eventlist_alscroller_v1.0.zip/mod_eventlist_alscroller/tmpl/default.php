<?php
/**
 * @version 1.0 $Id: default.php 258 2009-11-20 21:23:05Z jrgadrian $
 * @package Joomla
 * @subpackage AL EventList Scroller Module
 * @copyright (C) 2009 Adrian Levano. All rights reserved.
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * AL EventList Scroller Module is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 2
 * as published by the Free Software Foundation.

 * AL EventList Scroller Module is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * AL EventList Scroller Module is based on EventList Wide Module by Christoph Lukes
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Get gd version
$gd_version		= ELImage::gdVersion();
$cols			= !$params->get('columns')?1:$params->get('columns');
$rows			= !$params->get('rows')?1:$params->get('rows');
$_cols			= $cols;//!($totalitems < $cols)? $cols : $totalitems;
$_rows			= $rows;//!($totalitems < ($cols*$rows))? $rows : $rows - intval(($cols*$rows - $totalitems)/$cols);
$col_width		= floor(str_replace('%', '', str_replace('px', '', $params->get('width_module',160))) / $_cols);
$row_height		= floor(str_replace('%', '', str_replace('px', '', $params->get('heigth_module',200))) / $rows);

$module_width	= ($_cols*$col_width);
$module_height  = ($_rows*$row_height);
$padding		= $params->get('padding', 0);

$scrollaxis		= $params->get('scrollaxis', 0)?'y':'x';
$inner_width	= $scrollaxis=='x' ?30000:$module_width;
$inner_height	= $scrollaxis=='x' ?$module_height:30000;
?>

<div id="<?php echo $module_id; ?>" class="elmodscroll_container<?php echo $params->get('moduleclass_sfx'); ?>" style="width:<?php echo $module_width; ?>px;overflow: hidden;margin:0px auto;padding:0px;">
    <div class="elmodscroll_wrapper" style="width:<?php echo $module_width; ?>px;height:<?php echo $module_height; ?>px;overflow: hidden; margin:0px;padding:0px;">
		<div class="elmodscroll_inner" style="width:<?php echo $inner_width; ?>px;height:<?php echo $inner_height; ?>px;overflow: hidden;margin:0px;padding:0px;">
            <?php for($i = 0; $i * $cols * $rows < $totalitems; $i++) : ?>
            <div class="elmodscroll_content" style="width:<?php echo $module_width; ?>px;height:<?php echo $module_height; ?>px;float:left;overflow:hidden;margin:0px;padding:0px;">
				<?php for($j = 0; $j < $rows; $j++) : ?>
				<div class="elmodscroll_row<?php echo $j%2;?>" style="width:<?php echo $module_width; ?>px;height:<?php echo $row_height; ?>px;overflow:hidden;margin:0px;padding:0px;">
                    <?php for($k = 0; $k < $cols; $k++) : ?>
                    <div class="elmodscroll_column<?php echo $k%2;?>" style="width:<?php echo $col_width?>px;float:left;overflow:hidden;margin:0px;padding:0px;">
                        <?php
                            $offset = ($i * $cols * $rows) + ($j*$cols)+ $k;
                            if(isset($list[$offset])):
                                $item = $list[$offset];
                        ?>
                        <div class="elmodscroll_event-container" style="overflow:hidden;margin:0px;padding: <?php echo $padding; ?>;">
                            <?php
                            for($order = 1;$order < 9;$order++) :
                                if($params->get('event_image_order') == $order && $params->get('showimage') &&  $gd_version == 2 &&$item->eventimage):?>
                                    <?php if ($params->get('linkdet')==3||$params->get('linkdet')==4||$params->get('linkdet')==5) : ?>
                                    <a href="<?php echo $item->eventlink; ?>" title="<?php echo $item->title; ?>">
                                    <?php endif; ?>
                                        <img src="<?php echo $item->eventimage; ?>" alt="<?php echo $item->title; ?>" width="<?php echo $item->eventimagew; ?>" height="<?php echo $item->eventimageh; ?>" title="<?php echo $item->title; ?>" class="elmodscroll_event-image-<?php echo $params->get('imagefloat')?'right':'left'; ?>" />
                                    <?php if ($params->get('linkdet')==3 || $params->get('linkdet')==4 || $params->get('linkdet')==5) : ?>
                                    </a>
                                    <?php endif; ?>
                                <?php
                                endif;
                                if($params->get('event_title_order') == $order && $params->get('showtitle') && $item->title):?>
                                <div class="elmodscroll_event-title"> 
                                    <?php if ($params->get('linkdet')==1||$params->get('linkdet')==4) : ?>
                                    <a href="<?php echo $item->eventlink; ?>" title="<?php echo $item->title; ?>">
                                    <?php endif; ?>
                                        <span class="elmodscroll_event-title">
                                            <?php echo $item->title; ?>
                                        </span>
                                    <?php if ($params->get('linkdet')==1||$params->get('linkdet')==4) : ?>
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <?php
                                endif;
                                if($params->get('event_author_order') == $order && $params->get('showauthor') && $item->author):?>
                                <div class="elmodscroll_event-author">  
                                    <?php if ($params->get('linkcbprofile')):?>
                                    <a href="<?php echo $item->authorcbprofile; ?>" title="<?php echo $item->author; ?>">
                                    <?php endif; ?>
                                        <span class="elmodscroll_event-author">
                                            <?php echo $item->author; ?>
                                        </span>
                                    <?php if ($params->get('linkcbprofile')):?>
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <?php
                                endif;
                                if($params->get('event_datetime_order') == $order && $params->get('showdate')):?>
                                <div class="elmodscroll_event-datetime">
                                    <?php if ($params->get('linkdet')==2||$params->get('linkdet')==5) : ?>
                                    <a href="<?php echo $item->eventlink; ?>" title="<?php echo $item->title; ?>">
                                    <?php endif; ?>
                                    <span class="elmodscroll_event-date"><?php echo $item->date?><?php if($params->get('showenddate') && $item->enddate):?>&nbsp;-&nbsp;<?php echo $item->enddate;?><?php endif; ?></span>
                                    <?php if($params->get('showtime') && $item->time):?><span class="elmodscroll_event-time"><?php echo $item->time?><?php if($params->get('showendtime') && $item->endtime):?>&nbsp;-&nbsp;<?php echo $item->endtime;?><?php endif; ?></span><?php endif; ?>
                                    
                                    <?php if ($params->get('linkdet')==2||$params->get('linkdet')==5) : ?>
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <?php
                                endif;
                                if($params->get('event_category_order') == $order && $params->get('showcategory') && $item->catname):?>
                                <div class="elmodscroll_event-category">
                                    <?php if ($item->categorylink) : ?>
                                    <a href="<?php echo $item->categorylink; ?>" title="<?php echo $item->catname; ?>">
                                    <?php endif; ?>
                                        <span class="elmodscroll_event-category">
                                            <?php echo $item->catname; ?>
                                        </span>
                                    <?php if ($item->categorylink) : ?>
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <?php
                                endif;
                                if($params->get('event_venue_order') == $order && $params->get('showvenue') && $item->venue):?>
                                <div class="elmodscroll_event-venue">
                                    <?php if ($params->get('linkvenue') && $item->venuelink) : ?>
                                    <a href="<?php echo $item->venuelink; ?>" title="<?php echo $item->venue; ?>">
                                    <?php endif; ?>
                                        <span class="elmodscroll_event-venue-title">
                                            <?php echo $item->venue; ?>
                                        </span>
                                    <?php if ($params->get('linkvenue') && $item->venuelink) : ?>
                                    </a>
                                    <?php endif; ?>
                                    <?php if($params->get('showstreet') && $item->street): ?>
                                    <span class="elmodscroll_event-venue-street"><?php echo $item->street; ?></span>
                                    <?php endif; ?>
                                    <?php if($params->get('showcity') && $item->city): ?>
                                    <span class="elmodscroll_event-venue-city"><?php echo $item->city; ?><?php if($params->get('showstate') && $item->state) echo ',';?></span>
                                    <?php endif; ?>
                                    <?php if($params->get('showstate') && $item->state): ?>
                                    <span class="elmodscroll_event-venue-state"><?php echo $item->state; ?></span>
                                    <?php endif; ?>
                                    <?php if($params->get('showcountry') && $item->country): ?>
                                    <span class="elmodscroll_event-venue-country"><?php echo $item->countryimg ? $item->countryimg : $item->country; ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php
                                endif;
                                if($params->get('event_description_order') == $order && $params->get('showdescription') && $item->eventdescription):?>
                                <div class="elmodscroll_event-description">
                                    <span class="elmodscroll_event-description">
                                        <?php echo $item->eventdescription; ?>
                                    </span>
                                    <?php if($params->get('showreadmore', 1) ):?>
                                    <a href="<?php echo $item->eventlink; ?>" title="<?php echo $item->title; ?>" class="readon">
                                        <?php echo $params->get('readmoretext')? $params->get('readmoretext') : JText::sprintf('Read more...'); ?>
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <?php
                                endif;
                            endfor; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endfor; ?>
                </div>
                <?php endfor; ?>
            </div>
            <?php endfor; ?>
        </div>
    </div>
    <?php if( $totalitems > ($cols * $rows) && $params->get('shownavbar') ) : ?>
    <div class="elmodscroll_nav" style="width:<?php echo $module_width; ?>;overflow: hidden;">
            <ul>
                    <li class="elmodscroll_prev"><a href="#">&lt;</a></li>
                    <?php for($i = 0; $i * $cols * $rows < $totalitems; $i++) : ?>
                    <li class="elmodscroll_page <?php if($i==0)echo 'elmodscroll_current';?>"><a href="#"><?php echo $i+1; ?></a></li>
                    <?php endfor; ?>
                    <li class="elmodscroll_next"><a href="#">&gt;</a></li>
            </ul>
    </div>
    <?php endif; ?>
</div>