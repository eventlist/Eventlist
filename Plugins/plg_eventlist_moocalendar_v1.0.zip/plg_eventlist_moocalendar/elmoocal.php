<?php
/**
 * @version 1.0 $Id: helper.php 258 2010-05-28 21:23:05Z alevano $
 * @package Joomla
 * @subpackage AL EventList Mootools Calendar Plugin
 * @copyright (C) 2010 Adrian Levano. All rights reserved.
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * AL EventList Mootools Calendar Plugin is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 2
 * as published by the Free Software Foundation.

 * AL EventList Mootools Calendar Plugin is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

//require needed component classes


if (file_exists(JPATH_SITE.DS.'components'.DS.'com_eventlist'.DS.'helpers'.DS.'route.php')){
require_once(JPATH_SITE.DS.'components'.DS.'com_eventlist'.DS.'helpers'.DS.'route.php');
}else{
return;
}
if (!class_exists('ELMooCal')) {
	require_once(dirname(__FILE__).'/elmoocal/elmoocal.php');
}
/**
 * Example Content Plugin
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.5
 */
class plgContentELMooCal extends JPlugin
{

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	function plgContentELMooCal( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	function onPrepareContent(&$article, &$params, $limitstart) {

		// simple performance check to determine whether bot should process further
		if (JString::strpos($article->text, 'elmoocal') === false) {
			return true;
		}

		// get plugin info
		$plugin       =& JPluginHelper::getPlugin('content', 'elmoocal');
	 	$pluginParams = new JParameter($plugin->params);

	 	// expression to search for
		$regex = "#{elmoocal\s*(.*?)}#s";
		

		// check whether plugin has been unpublished
		if (!$pluginParams->get('enabled', 1)) {
			$article->text = preg_replace($regex, '', $article->text);
			return true;
		}

		// perform the replacement
		preg_match_all($regex, $article->text, $matches);
	
	 	if ($count = count($matches[0])) {
	 		$this->replace($article, $matches, $count, $regex, $pluginParams);
		}
    }

	function replace(&$article, &$matches, $count, $regex, $pluginParams) {
		
		JPlugin::loadLanguage( 'plg_content_elmoocal', JPATH_ADMINISTRATOR  );
		
		for ($i = 0; $i < $count; $i++) {

			// set line params
		 	$this->setParams($matches[1][$i]);
		 	
			// set calendar params
		 	$params = new JParameter('');
			$params->bind($pluginParams->toArray());
			$params->bind($this->parameter);
			$params->set('cfg_path', '/plugins/content/elmoocal/');
			$params->set('cfg_juri', JURI::root(true));
			$params->set('cfg_jroot', JPATH_ROOT);

			// render gallery
			$calendar =& new ELMooCal($params);
			$replace =  $calendar->render();

			// replace
			$article->text = str_replace($matches[0][$i], $replace, $article->text);
			
	 	}
	}	

	function setParams($param_line, $default = array()) {
		$matches = array();
		$this->parameter = $default;
		
		preg_match_all("#(\w+)=\[(.*?)\]#s", $param_line, $matches);
	    for ($i = 0; $i < count($matches[1]); $i++) {
			$this->parameter[strtolower($matches[1][$i])] = $matches[2][$i];
	    }
	}

}
