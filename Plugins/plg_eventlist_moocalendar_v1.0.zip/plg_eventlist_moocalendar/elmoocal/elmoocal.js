/* ELMooCalendar (C) 2010 Adrian Levano. All rights reserved.
 * Version 1.0 (Mootools 1.12) 
 * ELMooCalendar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * This script is based on Mootools Events Calendar v0.3.0 by http://dansnetwork.com/mootools/events-calendar
*/
var ELMooCalendar = new Class({
	
	options: {
		submiturl: '/plugins/content/el_moocal_ajax.php',
		calContainer: 'calBody',
		newDate: 0,
		view: 'month',
		jumpToMonth:true,
		feedSpan: 3,
		weekStart: 0,
		cEvents: [],
		days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
		shortDays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
		months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
		shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		params:'',
		dateFormat:'l, F j, Y',
		timeFormat:'h:i A',
		maxTipTitle:50
	},
	initialize: function(options){
		this.setOptions(options);
		
		this.container		= $(this.options.calContainer);
		this.viewContent	= this.container.getElement(".viewContent");
		this.monthPicker	= this.container.getElement(".liMonthPicker a");
		this.weekPicker		= this.container.getElement(".liWeekPicker a");
		this.dayPicker		= this.container.getElement(".liDayPicker a");
		this.prevCtrl		= this.container.getElement(".viewPrevCtrl a");
		this.nextCtrl		= this.container.getElement(".viewNextCtrl a");
		this.titleCtrl		= this.container.getElement(".viewTitle span");
		this.loading		= this.container.getElement(".elmoocal-loading");

		
		
		this.pluginParams = this.options.params;
		this.days = this.options.days;
		this.shortDays= this.options.shortDays;
		this.months = this.options.months;
		this.shortMonths= this.options.shortMonths;
		this.daysInMonth = 30;
		this.options.newDate != 0 ? this.calDate = new Date(this.options.newDate) : this.calDate = new Date();
		this.startingOffset = 0;
		this.viewStartDate = new Date();
		this.viewEndDate = new Date();
		this.gotEvents = false;
		this.eventRangeStart = new Date();
		this.eventRangeEnd = new Date();
		this.extendDate();
		this.setCalParams();
		
		this.monthPicker.addEvent('click',function(e){
			e = new Event(e).stop();
			this.showMonth();
		}.bind(this));
		
		this.weekPicker.addEvent('click',function(e){
			e = new Event(e).stop();
			this.showWeek();
		}.bind(this));
		
		this.dayPicker.addEvent('click',function(e){
			e = new Event(e).stop();
			this.showDay();
		}.bind(this));
		
		switch(this.options.view){
			case 'month':
				this.showMonth();
				break;
			case 'week':
				this.showWeek();
				break;
			case 'day':
				this.showDay();
				break;
			default:
				this.showMonth;
		}
		
	},
	setControls:function(calTitle){
		
		this.titleCtrl.setHTML(calTitle);
		
		this.prevCtrl.removeEvents('click'); 
		this.prevCtrl.addEvent('click',function(e){
			e = new Event(e).stop();
			switch(this.options.view){
				case 'month':
					this.showPrevMonth();
					break;
				case 'week':
					this.showPrevWeek();
					break;
				case 'day':
					this.showPrevDay();
					break;
			}
		}.bind(this));
		
		this.nextCtrl.removeEvents('click');
		this.nextCtrl.addEvent('click',function(e){
			e = new Event(e).stop();
			switch(this.options.view){
				case 'month':
					this.showNextMonth();
				break;
				case 'week':
					this.showNextWeek();
					break;
				case 'day':
					this.showNextDay();
					break;
			}			
		}.bind(this));

	},
	setDaysInMonth: function(month, year){
		var daysInMonths = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
		if(new Date(year,1,29).getDate() == 29)
			daysInMonths[1] = 29;
		this.daysInMonth = daysInMonths[month];
	},
	setStartingOffset: function(month,year){
		this.options.weekStart == 0 ? this.startingOffset = new Date(year,month,1).getDay() : this.startingOffset = (new Date(year,month,1).getMDay());
	},
	setDate: function(day){
		this.calDate.setDate(day);
	},
	setDateTime: function (time){
		this.calDate.setTime(time);
	}, 
	setCalParams: function(){
		this.setDaysInMonth(this.calDate.getMonth(), this.calDate.getFullYear());
		this.setStartingOffset(this.calDate.getMonth(), this.calDate.getFullYear());
	},
	showButtonsRow:function(){
		
	},
	showControlsRow: function(calTitle){

	},
	showDowRow: function(){
	},
	showNextMonth: function(){
		this.calDate.nextMonth();
		this.setCalParams();
		this.showMonth();
	},
	showPrevMonth: function(){
		this.calDate.prevMonth();
		this.setCalParams();
		this.showMonth();
	},
	showSelMonth: function(){
	    this.calDate.setFullYear($E('.yearSelector',this.container).getValue());
		this.calDate.setMonth($E('.monthSelector',this.container).getValue());
		this.setCalParams();
		this.showMonth();
	},
	showMonth: function(){
		
		this.options.view = 'month';
		this.viewContent.setHTML('');
		
		if(this.options.jumpToMonth){
			var year 	= this.calDate.getFullYear();
			var month	= this.calDate.getMonth();
			var calTit	= ''; 
			calTit +='<select class="monthSelector" onchange="'+this.options.calContainer+'.showSelMonth();">';
			for (var m = 0; m < this.months.length; m++){
				calTit+= '<option value="'+m+'" ' + (m==month?'selected="selected"':'') + '>' + this.months[m] + '</option>';
			}
			calTit +='</select>';
			calTit +='<select class="yearSelector" onchange="'+this.options.calContainer+'.showSelMonth();">';
			for (var y=year-5 ; y <= year+5; y++){
				calTit+= '<option value="'+y+'" ' + (y==year?'selected="selected"':'') + '>' + y + '</option>';
			}
			calTit+='</select>';
			this.setControls(calTit);
		} else {
			this.setControls(this.months[this.calDate.getMonth()]+' '+this.calDate.getFullYear());
		}
		var wDate = new Date(this.calDate);
		wDate.setDate(1 - this.startingOffset);
		
		var table = '<table class="monthContainer" border="0px" cellpadding="0px" cellspacing="0">';
		table+='<thead><tr class="monthHeader"><th class="dayName" width="2%" valign="middle"></th>';
		for (var i = 0; i < 7; i++){
			var j = 0;
			if (this.options.weekStart == 0) j = i;
			else j = (i == 6)? 0 : (i + 1);

			table+='<th class="dayName" width="14%" >'+this.days[j]+'</th>';
		}
		table+='</tr></thead><tbody>';
		
		var calDone = false;
		for (var i = 0; i < 6; i++){
			if(calDone) break;
					
			var weekNumber	= 0;
			var weekDate	= 0;
			var weekDays	= '';
			if(!weekNumber)weekNumber = wDate.getWeek(this.startingOffset);

			for (var j = 0; j < 7; j++){
				
				var tdClassName = 'dayContainer';
				var tdContent = '';
				var tdScript = '';
				
				var day  = ((j+1) + (i*7)) - this.startingOffset;
				if (day > 0 && day <= this.daysInMonth){
					if(!weekDate)weekDate = wDate.getDate();
					tdClassName += ' day ' + 'day'+day;
					tdScript += 'onselectstart="javascript:return false;" onmousedown="javascript:return false"';
					if(day == this.calDate.getDate()) tdClassName += ' selected';
					tdContent+='<div class="dayNumber" date="'+day+'"><a href="javascript:void(0);" date="'+day+'">'+wDate.getDate()+'</a></div>';
					tdContent+='<div class="dayContent" date="'+day+'"></div>';
					if(day == this.daysInMonth) calDone = true;
				} else{
					tdClassName+=' empty';
				}
				if ((this.options.weekStart == 0 && j==0) || 
						(this.options.weekStart != 0 && j==6)) tdClassName += ' holiday';
				
				weekDays+='<td class="'+tdClassName+'" date="'+day+'" '+ tdScript +' width="14%" valign="top">'+tdContent+'</td>';
				wDate.increment();
				
			}
			table+='<tr class="weekContainer">';
			table+='<td class="weekNumber" width="2%" valign="middle"><a href="#" date="'+weekDate+'">'+weekNumber+'</a></td>';
			table+=weekDays;
			table+='</tr>';
			
		}
		
		table += '</tbody></table>';
		
		var mView = new Element('div',{
			'class':'mView'
		}).setHTML(table);
		
		mView.getElements('.weekNumber a').addEvent('click',function(e){
			e = new Event(e).stop();
			this.setDate(e.target.getProperty('date'));
			this.showWeek();
		}.bind(this));
		
		mView.getElements('.dayNumber a').addEvent('click',function(e){
			e = new Event(e).stop();
			this.setDate(e.target.getProperty('date'));
			this.showDay();
		}.bind(this));
		
		mView.getElements('.day').addEvent('click',function(e){   
			e = new Event(e);
			mView.getElements('.day').removeClass('selected');    
			mView.getElements('.day'+e.target.getProperty('date')).addClass('selected');   
			this.setDate(e.target.getProperty('date'));
		}.bind(this));
		
		mView.getElements('.day').addEvent('dblclick',function(e){   
			e = new Event(e);
			this.setDate(e.target.getProperty('date'));
			this.showDay();
		}.bind(this));
		
		mView.inject(this.viewContent);
		
		this.viewStartDate.setTime(this.calDate.valueOf());
		this.viewStartDate.setDate(1);
		this.viewStartDate.clearTime();
		this.viewEndDate.setTime(this.calDate.valueOf());
		this.viewEndDate.setDate(this.daysInMonth);
		this.viewEndDate.endOfDay();
		this.getCalEvents();
		
	},
	showNextWeek: function(){
		var nWeek = this.calDate.getDate();
		this.calDate.setDate(nWeek+7);
		this.setCalParams();
		this.showWeek();
	},
	showPrevWeek: function(){
		var pWeek = this.calDate.getDate();
		this.calDate.setDate(pWeek-7);
		this.setCalParams();
		this.showWeek();
	},
	showWeek: function(){
		this.options.view = 'week';
		this.viewContent.setHTML('');
		
		var wStartDate = new Date(this.calDate);
		var dow = this.options.weekStart == 0 ? wStartDate.getDay() : wStartDate.getMDay();
		wStartDate.setDate(wStartDate.getDate()-dow);
		var wEndDate = new Date(wStartDate); 
		wEndDate.setDate(wEndDate.getDate()+6);
		
		this.setControls(wStartDate.format(this.options.dateFormat) + ' - '+ wEndDate.format(this.options.dateFormat));
		
		
		var wView = new Element('div',{
			'class':'wView'
		}).setHTML('<div class="weekContainer"></div>');
		
		var wDate = new Date(wStartDate);
		for(var i = 0; i < 7; i++){
			day  = wDate.getDate();
			
			var dayContainer = new Element('div',{
				'class':'dayContainer' + ' day' + day
				}).setHTML( '<div class="dayName"></div><div class="dayContent" date="'+day+'"></div>' ).inject(wView.getElement('.weekContainer'));
			
			var aWeekDayLink = new Element('a',{
				'href':'javascript:void(0)',
				'dateTime':wDate.getTime(),
				events:{
					click: function(e){
						e = new Event(e).stop();
						this.setDateTime(e.target.getProperty('dateTime'));
						this.showDay();
					}.bind(this)
				}
			}).setText(wDate.format(this.options.dateFormat)).inject(dayContainer.getElement('.dayName'));
			
			wDate.increment();
		}
		
		wView.inject(this.viewContent);	
		
		this.viewStartDate.setTime(wStartDate.valueOf());
		this.viewEndDate.setTime(wEndDate.valueOf());
		this.viewStartDate.clearTime();
		this.viewEndDate.endOfDay();
		this.getCalEvents();
		
	}, 
	showNextDay: function(){
		var nDay = this.calDate.getDate();
		this.calDate.setDate(nDay+1);
		this.setCalParams();
		this.showDay();
	},
	showPrevDay: function(){
		var pDay = this.calDate.getDate();
		this.calDate.setDate(pDay-1);
		this.setCalParams();
		this.showDay();
	},
	showDay: function(){
		this.options.view = 'day';
		this.viewContent.setHTML('');
		this.setControls(this.calDate.format(this.options.dateFormat));
		
		var dayView = new Element('div',{
			'class':'dView' + ' day' + this.calDate.getDate()
			}).setHTML('<div class="dayContent"></div>');
		dayView.inject(this.viewContent);
		
		this.viewStartDate.setTime(this.calDate.valueOf());
		this.viewEndDate.setTime(this.calDate.valueOf());
		this.viewStartDate.clearTime();
		this.viewEndDate.endOfDay();		
		this.getCalEvents();
	},
	getCalEvents: function(){
		
		if ((!this.gotEvents || this.viewStartDate < this.eventRangeStart || this.viewEndDate > this.eventRangeEnd)) {
			this.eventRangeStart.setTime(this.viewStartDate.getTime());
			this.eventRangeEnd.setTime(this.viewEndDate.getTime());
			this.eventRangeStart.setMonth(this.eventRangeStart.getMonth()-this.options.feedSpan);
			this.eventRangeEnd.setMonth(this.eventRangeEnd.getMonth()+this.options.feedSpan);
			
			new Ajax(this.options.submiturl, {
				method: 'post',
				data:{
					'startDate':this.eventRangeStart.ymd(),
					'endDate':this.eventRangeEnd.ymd(),
					'params':this.pluginParams
				}, 
				onRequest: function(){
					this.loading.setStyles({'display':'block'});  
				}.bind(this),
				onFailure: function(response){
					this.loading.setHTML('<p>An error has ocurred while retrieving the data....please reload the page or try again later</p>');
				}.bind(this),
				onComplete: function(response){
					if(response){
						var json = Json.evaluate(response);
						this.options.cEvents = json;
						this.gotEvents = true;
						this.loadCalEvents();
					}
					this.loading.setStyles({'display':'none'});
				}.bind(this)
			}).request();
		}
		else
			this.loadCalEvents();
	},
	loadCalEvents: function(){
	
		$$('div.elmoocaltool-tip').each(function(divs){divs.remove();});
		
		for(var i = 0; i < this.options.cEvents.length; i++){
			
			var eStart	= new Date(Date.parse(this.options.cEvents[i].start));
			var eEnd	= new Date(Date.parse(this.options.cEvents[i].end));
			var eTime	= (new Date(Date.parse(this.options.cEvents[i].time))).format(this.options.timeFormat);
			var eTitle	= (this.options.view != 'month')?this.options.cEvents[i].title:this.options.cEvents[i].cuttitle;
			
			if((eStart<=this.viewStartDate<=eEnd)||(eStart >= this.viewStartDate && eStart <= this.viewEndDate) || (eEnd >= this.viewStartDate && eEnd <= this.viewEndDate)){
				
				while(eStart <= eEnd){
					
					if (eStart >= this.viewStartDate && eStart <= this.viewEndDate) {
						
						var eventDiv = new Element('div',{
							'class': this.options.cEvents[i].catcolor
						});
						
						var eventSpan = new Element('span').setProperty('date', eStart.getDate()).inject(eventDiv);
							
						var eventLink = new Element('a',{
							'href': this.options.cEvents[i].eventlink
						}).setProperty('date', eStart.getDate()).setText(eTime + ' ' + eTitle).inject(eventSpan);
						
						if (this.options.view != 'month'){
							new Element('font',{
								'class': 'event-location'
							}).setText(' - '+this.options.cEvents[i].location).inject(eventSpan);
							new Element('p',{
								'class': 'event-description'
							}).setText(this.options.cEvents[i].description).inject(eventSpan);
						}
						
						var dayContentDiv = this.container.getElement('.day' + eStart.getDate()+' .dayContent');
		
						eventDiv.inject(dayContentDiv);
						
						if (this.options.view == 'month'){

							var tip = eTime + ' ' + this.options.cEvents[i].tooltiptit + '::';
							if(this.options.cEvents[i].tooltiploc) 
								tip += '@' + this.options.cEvents[i].tooltiploc + '<br/>';
							if(this.options.cEvents[i].tooltipdesc) 
								tip += this.options.cEvents[i].tooltipdesc;
							
							eventDiv.setProperty('title', tip);
							new Tips(eventDiv, {
								className:'elmoocaltool',
								showDelay: 400,
								hideDelay: 400,
								fixed: false,
								maxTitleChars: this.options.maxTipTitle,
								onShow: function(tip){
									tip.setStyle('opacity', '0.9');
								}
							});

						}
					}
					eStart.increment();
				}
				
			}
		}
	
	},	
	extendDate: function(){
		function prevMonth(){
			var thisMonth = this.getMonth();
			this.setMonth(thisMonth-1);
			if(this.getMonth() != thisMonth-1 && (this.getMonth() != 11 || (thisMonth == 11 && this.getDate() == 1))){
				this.setDate(0);
			}
		};
		function nextMonth(){
			var thisMonth = this.getMonth();
			this.setMonth(thisMonth+1);
			if(this.getMonth() != thisMonth+1 && this.getMonth() != 0)
				this.setDate(0);
		};
		function endOfDay(){
			this.setHours(23);
			this.setMinutes(59);
			this.setSeconds(59);
			this.setMilliseconds(999);
		};
		function getMDay(){ 
			if(this.getDay() == 0)
				return 6;
			else
				return this.getDay() - 1;
		};
		function ymd(){
			
			var y=this.getFullYear()+"";
			var M=this.getMonth()+1;
			var d=this.getDate();
			M = (M<0||M>9?"":"0")+M;
			d = (d<0||d>9?"":"0")+d;
			
			return y+'-'+ M +'-'+d;
		}
		function thTime(){ 
			var ampm = this.format('%p').toLowerCase();
			return this.format('%I:%M'+ampm);
		}
		function clearTime(){
			this.setHours(0);
			this.setMinutes(0);
			this.setSeconds(0);
			this.setMilliseconds(0);
		}
		function increment(){
			this.setDate(this.getDate()+1);
		}		
		function getWeek(dowOffset) {
			var determinedate = new Date();
		    determinedate.setFullYear(this.getFullYear(), this.getMonth(), this.getDate()+dowOffset);
		    var D = determinedate.getDay();
		    if(D == 0) D = 7;
		    determinedate.setDate(determinedate.getDate() + (4 - D));
		    var YN = determinedate.getFullYear();
		    var ZBDoCY = Math.floor((determinedate.getTime() - new Date(YN, 0, 1, -6)) / 86400000);
		    var WN = 1 + Math.floor(ZBDoCY / 7);
		    return WN;
		} 

		Date.prototype.nextMonth = nextMonth;
		Date.prototype.prevMonth = prevMonth;
		Date.prototype.endOfDay = endOfDay;
		Date.prototype.getMDay = getMDay;
		Date.prototype.ymd = ymd;
		Date.prototype.thTime = thTime;
		Date.prototype.clearTime = clearTime;
		Date.prototype.increment = increment;
		Date.prototype.getWeek = getWeek;
		Date.prototype.format=function(format){var returnStr='';var replace=Date.replaceChars;for(var i=0;i<format.length;i++){var curChar=format.charAt(i);if(i-1>=0&&format.charAt(i-1)=="\\"){returnStr+=curChar;}else if(replace[curChar]){returnStr+=replace[curChar].call(this);}else if(curChar!="\\"){returnStr+=curChar;}};return returnStr;};Date.replaceChars={shortMonths:this.shortMonths,longMonths:this.months,shortDays:this.shortDays,longDays:this.days,d:function(){return(this.getDate()<10?'0':'')+this.getDate();},D:function(){return Date.replaceChars.shortDays[this.getDay()];},j:function(){return this.getDate();},l:function(){return Date.replaceChars.longDays[this.getDay()];},N:function(){return this.getDay()+1;},S:function(){return(this.getDate()%10==1&&this.getDate()!=11?'st':(this.getDate()%10==2&&this.getDate()!=12?'nd':(this.getDate()%10==3&&this.getDate()!=13?'rd':'th')));},w:function(){return this.getDay();},z:function(){var d=new Date(this.getFullYear(),0,1);return Math.ceil((this-d)/86400000);},W:function(){var d=new Date(this.getFullYear(),0,1);return Math.ceil((((this-d)/86400000)+d.getDay()+1)/7);},F:function(){return Date.replaceChars.longMonths[this.getMonth()];},m:function(){return(this.getMonth()<9?'0':'')+(this.getMonth()+1);},M:function(){return Date.replaceChars.shortMonths[this.getMonth()];},n:function(){return this.getMonth()+1;},t:function(){var d=new Date();return new Date(d.getFullYear(),d.getMonth(),0).getDate()},L:function(){var year=this.getFullYear();return(year%400==0||(year%100!=0&&year%4==0));},o:function(){var d=new Date(this.valueOf());d.setDate(d.getDate()-((this.getDay()+6)%7)+3);return d.getFullYear();},Y:function(){return this.getFullYear();},y:function(){return(''+this.getFullYear()).substr(2);},a:function(){return this.getHours()<12?'am':'pm';},A:function(){return this.getHours()<12?'AM':'PM';},B:function(){return Math.floor((((this.getUTCHours()+1)%24)+this.getUTCMinutes()/60+this.getUTCSeconds()/3600)*1000/24);},g:function(){return this.getHours()%12||12;},G:function(){return this.getHours();},h:function(){return((this.getHours()%12||12)<10?'0':'')+(this.getHours()%12||12);},H:function(){return(this.getHours()<10?'0':'')+this.getHours();},i:function(){return(this.getMinutes()<10?'0':'')+this.getMinutes();},s:function(){return(this.getSeconds()<10?'0':'')+this.getSeconds();},u:function(){var m=this.getMilliseconds();return(m<10?'00':(m<100?'0':''))+m;},e:function(){return"Not Yet Supported";},I:function(){return"Not Yet Supported";},O:function(){return(-this.getTimezoneOffset()<0?'-':'+')+(Math.abs(this.getTimezoneOffset()/60)<10?'0':'')+(Math.abs(this.getTimezoneOffset()/60))+'00';},P:function(){return(-this.getTimezoneOffset()<0?'-':'+')+(Math.abs(this.getTimezoneOffset()/60)<10?'0':'')+(Math.abs(this.getTimezoneOffset()/60))+':00';},T:function(){var m=this.getMonth();this.setMonth(0);var result=this.toTimeString().replace(/^.+ \(?([^\)]+)\)?$/,'$1');this.setMonth(m);return result;},Z:function(){return-this.getTimezoneOffset()*60;},c:function(){return this.format("Y-m-d\\TH:i:sP");},r:function(){return this.toString();},U:function(){return this.getTime()/1000;}};

	}
	
});

ELMooCalendar.implement(new Options);
ELMooCalendar.implement(new Events);

