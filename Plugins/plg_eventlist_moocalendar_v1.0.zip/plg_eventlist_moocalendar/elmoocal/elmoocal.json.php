<?php
/**
 * @version 1.0 $Id: elmoocal_ajax.php 258 2010-05-28 21:23:05Z alevano $
 * @package Joomla
 * @subpackage AL EventList Mootools Calendar Plugin
 * @copyright (C) 2010 Adrian Levano. All rights reserved.
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * AL EventList Mootools Calendar Plugin is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 2
 * as published by the Free Software Foundation.

 * AL EventList Mootools Calendar Plugin is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */
	// Set flag that this is a parent file
	define( '_JEXEC', 1 );
	
	define('JPATH_BASE', dirname(__FILE__). '/../../..' );
	
	define( 'DS', DIRECTORY_SEPARATOR );
	
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	//require needed component classes
	require_once(JPATH_BASE .DS.'components'.DS.'com_eventlist'.DS.'helpers'.DS.'helper.php');
	require_once(JPATH_BASE .DS.'components'.DS.'com_eventlist'.DS.'helpers'.DS.'route.php');
	
	$mainframe 	= &JFactory::getApplication('site');
	$cfg 		= &JFactory::getConfig();
	$db  		= &JFactory::getDBO();
	$user		= &JFactory::getUser();
	$uri 		= &JURI::getInstance();
	$user_gid	= (int) $user->get('aid');

	// get date range
	$startDate	= JRequest::getString( 'startDate', '1900-01-01' );
	$endDate	= JRequest::getString( 'endDate', '9999-01-01' );
	
	// set params
 	$params = new JParameter('');
	$params->bind(unserialize(JRequest::getString('params')));
	
	$event_type     = $params->get( 'type', '1' );
	$catid          = trim( $params->get('catid') );
	$venid          = trim( $params->get('venid') );
	$stateloc       = JString::strtolower(trim( $params->get('stateloc') ) );
	$cityloc        = JString::strtolower(trim( $params->get('cityloc') ) );
	$countryloc     = JString::strtolower(trim( $params->get('countryloc') ) );
	$cuttitle		= $params->get('cuttitle', 18);
	$cutdesc		= $params->get('cutdesc', 50);
	$elversion		= $params->get('elversion',0);
	
	//only published events
	if ($event_type == 0) {
		$where = ' WHERE a.published = 1';
	}
	//published and archived
	if ($event_type == 1) {
		$where = ' WHERE (a.published = 1 or a.published=-1)';
	}
	
	//Build category selection query statement
	if ($catid) {
		$ids = explode( ',', $catid );
		JArrayHelper::toInteger( $ids );
		$categories = ' AND (c.id=' . implode( ' OR c.id=', $ids ) . ')';
	}

	//Build venue selection query statement
	if ($venid) {
		$ids = explode( ',', $venid );
		JArrayHelper::toInteger( $ids );
		$venues = ' AND (l.id=' . implode( ' OR l.id=', $ids ) . ')';
	}

	//Build state selection query statement
	if ($stateloc) {
		$rawstate = explode( ',', $stateloc );

		foreach ($rawstate as $val) {
			if ($val) {
				$state[] = '"'.trim($db->getEscaped($val)).'"';
			}
		}

		JArrayHelper::toString( $state );
		$states = ' AND (LOWER(l.state)='.implode(' OR LOWER(l.state)=',$state).')';
	}

	//Build city selection query statement
	if ($cityloc) {
		$rawcity = explode( ',', $cityloc );

		foreach ($rawcity as $val) {
			if ($val) {
				$city[] = '"'.trim($db->getEscaped($val)).'"';
			}
		}

		JArrayHelper::toString( $city );
		$cities = ' AND (LOWER(l.city)='.implode(' OR LOWER(l.city)=',$city).')';
	}
	
	//Build country selection query statement
	if ($countryloc) {
		$rawcountry = explode( ',', $countryloc );

		foreach ($rawcountry as $val) {
			if ($val) {
				$country[] = '"'.trim($db->getEscaped($val)).'"';
			}
		}

		JArrayHelper::toString( $country );
		$countries = ' AND (LOWER(l.country)='.implode(' OR LOWER(l.country)=',$country).')';
	}	
	
	//perform select query
	$query = 'SELECT a.id, a.title, a.dates, a.enddates, a.datdescription, a.times, a.endtimes, a.datimage, l.venue, l.street, l.city, l.state, l.country, l.locimage, c.id as catid, c.catname,'
	.' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(\':\', a.id, a.alias) ELSE a.id END as slug,'
	.' CASE WHEN CHAR_LENGTH(l.alias) THEN CONCAT_WS(\':\', l.id, l.alias) ELSE l.id END as venueslug,'
	.' CASE WHEN CHAR_LENGTH(c.alias) THEN CONCAT_WS(\':\', c.id, c.alias) ELSE c.id END as categoryslug'
	.' FROM #__eventlist_events AS a'
	.($elversion?(
         ' INNER JOIN #__eventlist_cats_event_relations AS rel ON rel.itemid = a.id'
        .' LEFT JOIN #__eventlist_categories AS c ON c.id = rel.catid')
	:' LEFT JOIN #__eventlist_categories AS c ON c.id = a.catsid')
	.' LEFT JOIN #__eventlist_venues AS l ON l.id = a.locid'
	. $where
	.' AND ((DATE(a.dates) >= DATE('.$db->Quote($startDate).') AND DATE(a.dates) <= DATE('.$db->Quote($endDate).'))
				OR (a.enddates IS NOT NULL AND DATE(a.enddates) >= DATE('.$db->Quote($startDate).') AND DATE(a.enddates) <= DATE('.$db->Quote($endDate).')))'
	.' AND c.access <= '.$user_gid
	//.($showimage && $eventswithouthimage==2? ' AND a.datimage !=""':'')//supress events withouth image from results
	.($catid ? $categories : '')
	.($venid ? $venues : '')
	.($stateloc ? $states : '')
	.($cityloc ? $cities : '')
	.($countryloc ? $countries : '')
	//.($eveid ? $events : '')
	.($elversion? ' GROUP BY a.id':'')
	.' ORDER BY a.dates ASC, a.times ASC'
	;
	
	$db->setQuery($query);
	$rows = $db->loadObjectList();	
	
	//Loop through the result rows and prepare data
	$i = 0;
	$lists = array();
	$tooltip = "{time} {title}::@ {venue}<br/>{description}";
	foreach ( $rows as $row ) {
		
		$lists[$i] = array();
		
		$lists[$i]['title']		= $row->title;
		$lists[$i]['cuttitle']	= bite_str($row->title,0,$cuttitle);
		$lists[$i]['eventlink'] = $params->get('uri').'/'.(EventListHelperRoute::getRoute($row->id));
		$lists[$i]['start']		= _format_date($row->dates, $row->times, '%Y/%m/%d');
		$lists[$i]['end']		= !empty($row->enddates)?_format_date($row->enddates, $row->times, '%Y/%m/%d'):$lists[$i]['start'];
		$lists[$i]['time']	    = _format_date($row->dates, $row->times, '%Y/%m/%d %H:%M');
		$lists[$i]['location']	= $row->venue?$row->venue:'';
		$lists[$i]['city']		= $row->city;
		$lists[$i]['catname']	= $row->catname;
		
		// Trim description
		$description = trim($row->datdescription);
		// Remove description plugins
		$description = preg_replace("/\{.+?\}/", "", $description);
		// Strip description HTML Tags
		$description = _strip_html_tags($description);
		// Strip description BBCode Tags
		$description = _strip_BBCode($description);
		// Cut Description
		$description = bite_str($description,0,$cutdesc);
		$lists[$i]['description']	= $description;
		$lists[$i]['catcolor']		= 'category-color'.$row->catid;
		
		//Tooltip
		$lists[$i]['tooltiptit']	= htmlspecialchars( $row->title, ENT_COMPAT, 'UTF-8' );
		$lists[$i]['tooltiploc']	= htmlspecialchars( $row->venue, ENT_COMPAT, 'UTF-8' );
		$lists[$i]['tooltipcity']	= htmlspecialchars( $row->city, ENT_COMPAT, 'UTF-8' );
		$lists[$i]['tooltipcat']	= htmlspecialchars( $row->catname, ENT_COMPAT, 'UTF-8' );
		$lists[$i]['tooltipdesc']	= htmlspecialchars( $description, ENT_COMPAT, 'UTF-8' );

		$i++;
	}
	
	// Get the document object.
	$document =& JFactory::getDocument();
	// Set the MIME type for JSON output.
	$document->setMimeEncoding( 'application/json' );
	
	if (function_exists('json_encode')){
		echo json_encode($lists);
	} else {
		echo _json_encode($lists);
	}
	
	/**
	 * Method to substitute if json_encode is not defined
	 *
	 * @access public
	 * @param array $a
	 * @return string
	 */
	function _json_encode($a=false){
		
		if (is_null($a)) return 'null';
		if ($a === false) return 'false';
		if ($a === true) return 'true';
		if (is_scalar($a)){
			if (is_float($a)){
				// Always use "." for floats.
				return floatval(str_replace(",", ".", strval($a)));
			}
			if (is_string($a)){
				static $jsonReplaces = array(array("\\", "/", "\n", "\t", "\r", "\b", "\f", '"'), array('\\\\', '\\/', '\\n', '\\t', '\\r', '\\b', '\\f', '\"'));
				return '"' . str_replace($jsonReplaces[0], $jsonReplaces[1], $a) . '"';
			}
      		else
			return $a;
		}
		$isList = true;
		for ($i = 0, reset($a); $i < count($a); $i++, next($a)) {
			if (key($a) !== $i){
				$isList = false;
				break;
			}
		}
		$result = array();
		if ($isList) {
			foreach ($a as $v) $result[] = _json_encode($v);
			return '[' . join(',', $result) . ']';
    		}
    		else {
      		foreach ($a as $k => $v) $result[] = _json_encode($k).':'._json_encode($v);
      		return '{' . join(',', $result) . '}';
		}
	}
	
	// String intercept By Bleakwind
	// utf-8:$byte=3 | gb2312:$byte=2 | big5:$byte=2
	function bite_str($string, $start, $len, $byte=3)
	{
	    $str     = "";
	    $count   = 0;
	    $str_len = strlen($string);
	    for ($i=0; $i<$str_len; $i++) {
	        if (($count+1-$start)>$len) {
	            $str  .= "...";
	            break;
	        } elseif ((ord(substr($string,$i,1)) <= 128) && ($count < $start)) {
	            $count++;
	        } elseif ((ord(substr($string,$i,1)) > 128) && ($count < $start)) {
	            $count = $count+2;
	            $i     = $i+$byte-1;
	        } elseif ((ord(substr($string,$i,1)) <= 128) && ($count >= $start)) {
	            $str  .= substr($string,$i,1);
	            $count++;
	        } elseif ((ord(substr($string,$i,1)) > 128) && ($count >= $start)) {
	            $str  .= substr($string,$i,$byte);
	            $count = $count+2;
	            $i     = $i+$byte-1;
	        }
	    }
	    return $str;
	}
	
	/**
	 * Method to remove HTML tags, including invisible text such as
	 * style and script code, and embedded objects. Add line breaks
	 * around block-level tags to prevent word joining after tag removal.
	 *
	 * @access public
	 * @param string $text
	 * @return string
	 */
	function _strip_html_tags( $text )
	{
		$text = preg_replace(
		array(
		// Remove invisible content
	            '@<head[^>]*?>.*?</head>@siu',
	            '@<style[^>]*?>.*?</style>@siu',
	            '@<script[^>]*?.*?</script>@siu',
	            '@<object[^>]*?.*?</object>@siu',
	            '@<embed[^>]*?.*?</embed>@siu',
	            '@<applet[^>]*?.*?</applet>@siu',
	            '@<noframes[^>]*?.*?</noframes>@siu',
	            '@<noscript[^>]*?.*?</noscript>@siu',
	            '@<noembed[^>]*?.*?</noembed>@siu',
		// Add line breaks before and after blocks
	            '@</?((address)|(blockquote)|(center)|(del))@iu',
	            '@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
	            '@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
	            '@</?((table)|(th)|(td)|(caption))@iu',
	            '@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
	            '@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
	            '@</?((frameset)|(frame)|(iframe))@iu',
		),
		array(
	            ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	            "\$0", "\$0", "\$0", "\$0", "\$0", "\$0",
	            "\$0", "\$0",
		),
		$text );
		return strip_tags( $text );
	}

	/**
	 * Method to remove BBcode tags.
	 *
	 * @access public
	 * @param string $text
	 * @return string
	 */
	function _strip_BBCode($text_to_search) {
		$pattern = '|[[\/\!]*?[^\[\]]*?]|si';
		$replace = '';
		return preg_replace($pattern, $replace, $text_to_search);
	}
	
	/**
	 * Method to format date information
	 * @access public
	 * @param string $date
	 * @param string $time
	 * @param string $format
	 * @return string
	 */
	function _format_date($date, $time, $format) {
		//format date
		$date = strftime($format, strtotime( $date.' '.$time ));
		return $date;
	}
?>