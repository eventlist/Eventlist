<?php
/**
 * @version 1.0 $Id: elmoocal.php 258 2010-05-28 21:23:05Z alevano $
 * @package Joomla
 * @subpackage AL EventList Mootools Calendar Plugin
 * @author Adrian Levano
 * @copyright (C) 2010 Adrian Levano. All rights reserved.
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * AL EventList Mootools Calendar Plugin is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 2
 * as published by the Free Software Foundation.

 * AL EventList Mootools Calendar Plugin is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */
// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

class ELMooCal {
    
	// calendar params
	var $params;

	// calendar path
	var $path;
    
	// calendar uri
	var $uri;

	// joomla root
	var $jroot;

	// joomla uri
	var $juri;

	function ELMooCal($params) {
		$this->params = $params;
		$this->jroot  = $params->get('cfg_jroot');
		$this->juri   = $params->get('cfg_juri');
		$this->path   = $params->get('cfg_path');
		$this->uri    = $this->juri.$this->path;
	}

	function render() {
			
		// init vars
		$title			= $this->params->get('title', '');
		$style			= $this->params->get('style', 'default');
		$catid			= $this->params->get('catid','');
		$feedspan		= $this->params->get('feedspan',1);
		$jumptomonth	= $this->params->get('jumptomonth',0);
		$weekstart		= $this->params->get('weekstart',1);
		$monthoffset	= $this->params->get('monthoffset',0);
		$maxtiptitle	= $this->params->get('maxtiptitle', 50);
		$dateformat		= $this->params->get('dateformat','l, F j, Y');
		$timeformat		= $this->params->get('timeformat','H:i');
		$view			= $this->params->get('view','month');
		$tmpl_style		= dirname(__FILE__).'/tmpl/'.$style.'.php';
	
		// check event template files
		if (!is_readable($tmpl_style)) {
			return $this->getAlertMessage("Unable to read the eventnail style template files");
		}
	
		$categories = $this->getCategories();
		
		// add css
		if ($this->includeOnce('ELMOOCALENDAR_CSS')) {
			$document =& JFactory::getDocument();
			$document->addStyleSheet($this->uri.'styles/calendar_'.$style.'/style.css');
		}
		
		
		// init template vars
	   	static $calendar_count = 1;
		$calendar_id = 'elmoocalendar'.$calendar_count++;
		
		$extraParams = array();
		$extraParams['event_type'] 	= $this->params->get('type', '1');
		$extraParams['catid']		= $this->params->get('catid');
		$extraParams['venid']		= $this->params->get('venid');
		$extraParams['stateloc']	= $this->params->get('stateloc') ;
		$extraParams['cityloc']		= $this->params->get('cityloc');
		$extraParams['countryloc']	= $this->params->get('countryloc') ;
		$extraParams['cuttitle']	= $this->params->get('cuttitle', 18);
		$extraParams['cutdesc']		= $this->params->get('cutdesc', 50);
		$extraParams['elversion']	= $this->params->get('elversion', 0);
		$extraParams['uri']			= $this->juri;
		
		//Month Offset
		
		$date = getdate();
		$time = mktime(0, 0, 0, $date['mon']+$monthoffset, $monthoffset?1:$date['mday'], $date['year']);
		$newDate  = strftime ('%Y/%m/%d',$time);

		
		$document =& JFactory::getDocument();
		$document->addScript ( $this->uri . 'elmoocalcomp.js' );
		$js = "
		var $calendar_id = null;
		window.addEvent('domready', function(){
			$calendar_id = new ELMooCalendar({
				submiturl: '".$this->uri."elmoocal.json.php',
				calContainer:'".$calendar_id."',
				jumpToMonth:".$jumptomonth.",
				feedSpan:".$feedspan.",
				weekStart:".$weekstart.",
				newDate:'".$newDate."',
				view:'".$view."',
				days: ['".JText::_('Sunday')."', '".JText::_('Monday')."', '".JText::_('Tuesday')."', '".JText::_('Wednesday')."', '".JText::_('Thursday')."', '".JText::_('Friday')."', '".JText::_('Saturday')."'],// Day Names
				shortDays: ['".JText::_('Sun')."', '".JText::_('Mon')."', '".JText::_('Tuesday')."', '".JText::_('Wed')."', '".JText::_('Thu')."', '".JText::_('Fri')."', '".JText::_('Sat')."'],// Short Day Names
				months: ['".JText::_('January')."', '".JText::_('February')."', '".JText::_('March')."', '".JText::_('April')."', '".JText::_('May')."', '".JText::_('June')."', '".JText::_('July')."', '".JText::_('August')."', '".JText::_('September')."', '".JText::_('October')."', '".JText::_('November')."', '".JText::_('December')."'], //Month Names
				shortMonths: ['".JText::_('Jan')."', '".JText::_('Feb')."', '".JText::_('Mar')."', '".JText::_('Apr')."', '".JText::_('May')."', '".JText::_('Jun')."', '".JText::_('Jul')."', '".JText::_('Aug')."', '".JText::_('Sep')."', '".JText::_('Oct')."', '".JText::_('Nov')."', '".JText::_('Dec')."'], //Short Month Names
				params:'".serialize($extraParams)."',
				dateFormat:'$dateformat',
				timeFormat:'$timeformat',
				maxTipTitle:$maxtiptitle
			});
		});		
		";
		$document->addScriptDeclaration ( $js );		
		
		// get template output
		$html = '';
		ob_start();
		include($tmpl_style);
		$html = ob_get_contents();
		ob_end_clean();		
	
		return $html;
	}
	
	function getCategories(){
		$db = &JFactory::getDBO();
		$query = 'SELECT c.id,c.catname FROM #__eventlist_categories AS c WHERE c.published=1 ORDER BY c.catname';
		$db->setQuery($query);
		return $db->loadObjectList();
	}
	
	function getAlertMessage($msg) {
		return "<div class=\"alert\"><strong>".$msg."</strong></div>\n";
	}

	function includeOnce($name) {
		if (!defined($name)) {
			define($name, true);
			return true;
		}
		
		return false;
	}

}
?>