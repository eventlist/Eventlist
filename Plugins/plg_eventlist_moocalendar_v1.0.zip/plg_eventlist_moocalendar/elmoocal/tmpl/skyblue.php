<?php
/**
 * @version 1.0 $Id: plain.php 258 2010-05-28 21:23:05Z alevano $
 * @package Joomla
 * @subpackage AL EventList Mootools Calendar Plugin
 * @author Adrian Levano
 * @copyright (C) 2010 Adrian Levano. All rights reserved.
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * AL EventList Mootools Calendar Plugin is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 2
 * as published by the Free Software Foundation.

 * AL EventList Mootools Calendar Plugin is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */
// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div class="<?php echo $style; ?>">
	<div id="<?php echo $calendar_id;?>" class="elmoocal">
		<div class="elmoocal-loading"></div>
		<div class="viewContainer">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="viewHeader">
						<div class="viewPrevCtrl"><a href="javascript:void(0)"><?php echo JText::_('Previous');?></a></div>
						<div class="viewNextCtrl"><a href="javascript:void(0)"><?php echo JText::_('Next');?></a></div>
						<div class="viewTitle"><span>March 2010</span></div>
						<div class="viewPicker">
							<ul class="ulViewPicker">
								<li class="liMonthPicker">
									<a href="javascript:void(0)" class="aMonthPicker"><?php echo JText::_('Monthly View');?></a>
								</li>
								<li class="liWeekPicker">
									<a href="javascript:void(0)" class="aWeekPicker"><?php echo JText::_('Weekly View');?></a>
								</li>
								<li class="liDayPicker">
									<a href="javascript:void(0)" class="aDayPicker"><?php echo JText::_('Daily View');?></a>
								</li>										
							</ul>
						</div>
					</td>
				</tr>
				<tr>
					<td class="viewContent"></td>
				</tr>
				<tr>
					<td class="viewCategories">
						<ul class="category-list">
						<?php
						foreach ( $categories as $category ) {
							if(!$catid || in_array($category->id,explode( ',', $catid ))){
								$categorylink= JRoute::_( EventListHelperRoute::getRoute($category->id, 'categoryevents') );
						?>
							<li class="category-color<?php echo $category->id;?>">
								<span><a href="<?php echo $categorylink;?>"><?php echo $category->catname;?></a></span>
							</li>
						<?php
							}
						}
						?>									
						</ul>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>
<?php
//keep session alive while editing
JHTML::_('behavior.keepalive');
?>